package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<chatModel> arrChat = new ArrayList<>();
    EditText chatMessage ;
    ImageButton sendButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sendButton = findViewById(R.id.chat_send_btn);

        chatMessage = findViewById(R.id.edit_text_chat);
        RecyclerView recyclerView = findViewById(R.id.chatView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        sendButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String message = chatMessage.getText().toString().trim();
                if(message.isEmpty()){
                    return;
                }
                chatModel model = new chatModel(message);
                arrChat.add(model);
            }
        });
//        RecyclerChatAdapter recyclerChatAdapter = new RecyclerChatAdapter(this,arrChat);
//        recyclerView.setAdapter(recyclerChatAdapter);
        RecyclerChatAdapter recyclerChatAdapter = new RecyclerChatAdapter(this,arrChat);
        LinearLayoutManager manager = new LinearLayoutManager(this);
//        manager.setReverseLayout(true);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(recyclerChatAdapter);
//        recyclerChatAdapter.startListening();
        recyclerChatAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);
                recyclerView.smoothScrollToPosition(0);
            }
        });
    }
}